import createSchema from '../schema';

describe('createSchema', () => {
  it('creates schema without errors', () => {
    createSchema();

    expect(true).toBe(true);
  });
});
