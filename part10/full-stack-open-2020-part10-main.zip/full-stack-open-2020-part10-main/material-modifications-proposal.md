# Course Material Modifications Proposal

## Part 3

### Course Page Material

- Exercise 10.14 title has a typo in "storing the **acess**..."

### Rate Repository Backend Api

- The package.json's **build** script doesn't run properly using Powershell to run the script. In Powershell, instead of `&&`, multiple commands executions are achieved separating each with `;`

## Part 4

### Course Page Material

- **Style components section**. Referencing "variable-name" syntax as snake_case when it should be kebab-case

- Exercise 10.24: